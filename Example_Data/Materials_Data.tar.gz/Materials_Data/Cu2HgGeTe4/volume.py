
import numpy as np
import os

poscar_file = open("CONTCAR").readlines()

a1 = np.asarray([float(i) for i in poscar_file[2].split()])
a2 = np.asarray([float(i) for i in poscar_file[3].split()])
a3 = np.asarray([float(i) for i in poscar_file[4].split()])

print(a1, a2, a3)


print(np.cross(a2, a3))

vol = np.dot(a1, np.cross(a2, a3))

print(vol)

