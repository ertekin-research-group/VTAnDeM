import os
import pandas as pd
import numpy as np
import sys

eigenval='EIGENVAL'  

def get_nbands_kvbm_kcbm():
    out=open(eigenval,'r')
    list_lines=[]
    for line in out.readlines():
        list_lines.append(line)
    nelec=list_lines[5].split()[0]
    k_vbm=int(float(nelec)/2)
    k_cbm=int(k_vbm+1)
    #    if 'E-fermi' in line:
    #        efermi=line.split()[2]
    return k_vbm,k_cbm, nelec

k_vbm,k_cbm,nelec=get_nbands_kvbm_kcbm()

def fget_VBM():
    out=open(eigenval,'r')
    en_vbm=[]
    en_cbm=[]
    for line in out.readlines():
        cols=line.split()
        ncols=len(cols)
        if (ncols==3) and (cols[0]==str(k_vbm)):
            en_vbm.append(float(cols[1]))
        elif (ncols==3) and (cols[0]==str(k_cbm)):
            en_cbm.append(float(cols[1]))
    en_vbm.sort()
    en_cbm.sort()
    VBM=en_vbm[-1]
    CBM=en_cbm[0]
    E_gap= CBM-VBM  
    return VBM,CBM,E_gap

VBM,CBM,E_gap=fget_VBM()
print()
print('**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~**')
print()
print('  # of electrons: '+str(nelec))
print('  # of filled bands: '+str(k_vbm))
#print('  Efermi = '+str(efermi)+' eV')
print('  VBM = '+str(VBM)+' eV')
print('  CBM = '+str(CBM)+' eV')
print('  Egap = '+str(E_gap)+' eV')
print()
print('**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~**')
print()
