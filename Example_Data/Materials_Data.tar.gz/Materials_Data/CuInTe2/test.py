
import numpy as np

"""
from pymatgen.io.vasp.outputs import Vasprun
x = Vasprun("vasprun.xml")
print(x.complete_dos)
print(x._parse_dos)
"""

from lxml import etree
file = etree.parse("vasprun.xml")
fileroot = file.getroot()
for f in fileroot.iterchildren():
	if f.tag == "calculation":
		for i in f.iterchildren():
			if i.tag == "dos":
				for j in i.findall("i"):
					if j.attrib.get("name") == "efermi":
						print(float(j.text)) # fermi level
				for s in i.find("total").find("array").findall("set"):
					for ss in s.findall("set"):
						for sss in ss:
							y = []
							for z in sss.text.split():
								try:
									y.append(float(z))
								except:
									y.append(0.0)
									pass
							print(y)
